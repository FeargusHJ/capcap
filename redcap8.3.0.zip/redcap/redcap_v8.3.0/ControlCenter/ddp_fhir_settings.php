<?php
/*****************************************************************************************
**  REDCap is only available through a license agreement with Vanderbilt University
******************************************************************************************/

// If auto-finding FHIR token/authorize URLs
if (isset($_POST['url'])) 
{
	// Config for non-project pages
	require_once dirname(dirname(__FILE__)) . "/Config/init_global.php";
	// Call the URL
	$headers = array("Accept: application/json");
	$response = http_get($_POST['url'], 10, "", $headers);
	$metadata = json_decode($response, true);
	if (!is_array($metadata)) exit('0');
	// Get authorize endpoint URL and token endpoint URL
	$authorizeUrl = $tokenUrl = "";
	foreach ($metadata['rest'][0]['security']['extension'][0]['extension'] as $attr) {
		if ($attr['url'] == 'authorize') {
			$authorizeUrl = $attr['valueUri'];
		} elseif ($attr['url'] == 'token') {
			$tokenUrl = $attr['valueUri'];
		}
	}
	if ($authorizeUrl == "" || $tokenUrl == "") exit('0');
	// Return URLs
	exit("$authorizeUrl\n$tokenUrl");
}

include 'header.php';
if (!SUPER_USER) redirect(APP_PATH_WEBROOT);


$changesSaved = false;

// If project default values were changed, update redcap_config table with new values
if ($_SERVER['REQUEST_METHOD'] == 'POST')
{
	$changes_log = array();
	$sql_all = array();
	foreach ($_POST as $this_field=>$this_value) {
		// Save this individual field value
		$sql = "UPDATE redcap_config SET value = '".db_escape($this_value)."' WHERE field_name = '$this_field'";
		$q = db_query($sql);

		// Log changes (if change was made)
		if ($q && db_affected_rows() > 0) {
			$sql_all[] = $sql;
			$changes_log[] = "$this_field = '$this_value'";
		}
	}

	// Log any changes in log_event table
	if (count($changes_log) > 0) {
		Logging::logEvent(implode(";\n",$sql_all),"redcap_config","MANAGE","",implode(",\n",$changes_log),"Modify system configuration");
	}

	$changesSaved = true;
}

// Retrieve data to pre-fill in form
$element_data = array();

$q = db_query("select * from redcap_config");
while ($row = db_fetch_array($q)) {
		$element_data[$row['field_name']] = $row['value'];
}

// Set values if they are invalid
if (!is_numeric($element_data['fhir_stop_fetch_inactivity_days']) || $element_data['fhir_stop_fetch_inactivity_days'] < 1) {
	$element_data['fhir_stop_fetch_inactivity_days'] = 7;
}
if (!is_numeric($element_data['fhir_data_fetch_interval']) || $element_data['fhir_data_fetch_interval'] < 1) {
	$element_data['fhir_data_fetch_interval'] = 24;
}

?>

<?php
if ($changesSaved)
{
	// Show user message that values were changed
	print  "<div class='yellow' style='margin-bottom: 20px; text-align:center'>
			<img src='".APP_PATH_IMAGES."exclamation_orange.png'>
			{$lang['control_center_19']}
			</div>";
}
?>

<div style="font-size:18px;">
	<div class="pull-left" style="margin-top:10px;"><?php echo RCView::img(array('src'=>'fhir.png')) . $lang['ws_206'] ?></div>
	<div class="pull-right" style="margin-right:30px;">
		<?php echo RCView::img(array('src'=>'ehr_fhir.png')) ?>
		<span class="glyphicon glyphicon-plus" style="top:5px;margin:0px 25px 0;color:#777;font-size:20px;" aria-hidden="true"></span>
		<?php echo RCView::img(array('src'=>'ehr_embed.png', 'style'=>'position: relative;top: 2px;')) ?>
	</div>
</div>
<div class="clear"></div>

<?php
print RCView::p(array('style'=>''), $lang['ws_207']);
print RCView::p(array('style'=>''), $lang['ws_208']);
print RCView::div(array('style'=>'margin-bottom:5px;'),
		RCView::img(array('src'=>'folder_zipper.png')) .
		RCView::a(array('target'=>"_blank", 'href'=>APP_PATH_WEBROOT."Resources/misc/redcap_ddp_fhir_setup.zip", 'style'=>'color:#826204;text-decoration:underline;'), $lang['ws_236'])
	  );
print RCView::div(array('style'=>'margin-bottom:30px;'),
		RCView::img(array('src'=>'link.png')) .
		RCView::a(array('target'=>"_blank", 'href'=>APP_PATH_WEBROOT."DynamicDataPull/info.php?type=fhir", 'style'=>'text-decoration:underline;'), $lang['ws_98'])
	  );
?>

<form action='ddp_fhir_settings.php' enctype='multipart/form-data' target='_self' method='post' name='form' id='form'>
<?php
// Go ahead and manually add the CSRF token even though jQuery will automatically add it after DOM loads.
// (This is done in case the page is very long and user submits form before the DOM has finished loading.)
print "<input type='hidden' name='redcap_csrf_token' value='".System::getCsrfToken()."'>";
?>
<table style="border: 1px solid #ccc; background-color: #f0f0f0; width: 100%;">


<tr>
	<td class="cc_label">
		<?php echo $lang['ws_215'] ?>
	</td>
	<td class="cc_data">
		<select class="x-form-text x-form-field" style="" name="fhir_ddp_enabled">
			<option value='0' <?php echo ($element_data['fhir_ddp_enabled'] == 0) ? "selected" : "" ?>><?php echo $lang['global_23'] ?></option>
			<option value='1' <?php echo ($element_data['fhir_ddp_enabled'] == 1) ? "selected" : "" ?>><?php echo $lang['system_config_27'] ?></option>
		</select>
		<div class="cc_info">
			<?php echo $lang['ws_216'] ?>
		</div>
	</td>
</tr>

<tr>
	<td class="cc_label">
		<?php echo $lang['ws_214'] ?>
		<div class="cc_info" style="margin-bottom:20px;">
			<?php echo $lang['ws_235'] ?>
		</div>
	</td>
	<td class="cc_data">
		<input class='x-form-text x-form-field' style='width:150px;' type='text' name='fhir_source_system_custom_name' value='<?php echo htmlspecialchars($element_data['fhir_source_system_custom_name'], ENT_QUOTES) ?>' /><br/>
		<div class="cc_info">
			e.g., Epic, Cerner, EMR, EDW
		</div>
	</td>
</tr>

<tr>
	<td class="cc_label" style="font-weight:normal;border-top:1px solid #ccc;" colspan="2">
		<div style="margin-bottom:10px;font-weight:bold;color:#C00000;"><?php echo $lang['ws_237'] ?></div>
		<div style="margin-bottom:10px;"><?php echo $lang['ws_238'] ?></div>
		<b><?php echo $lang['ws_239'] ?></b>
		<input id="redirectURL" value="<?php echo APP_PATH_WEBROOT_FULL ?>ehr.php" onclick="this.select();" readonly="readonly" class="staticInput" style="width:80%;max-width:400px;margin-bottom:5px;margin-right:5px;">
		<button class="btn btn-defaultrc btn-xs btn-clipboard" title="Copy to clipboard" onclick="return false;" data-clipboard-target="#redirectURL" style="padding:3px 8px 3px 6px;"><span class="glyphicon glyphicon-copy"></span></button>
	</td>
</tr>

<tr>
	<td class="cc_label" style="border-top:1px solid #ccc;color:#C00000;" colspan="2">
		<?php echo $lang['ws_234'] ?>
	</td>
</tr>

<tr>
	<td class="cc_label">
		<?php echo $lang['ws_219'] ?>
		<div class="cc_info">
			<?php echo $lang['ws_220'] ?>
		</div>
	</td>
	<td class="cc_data">
		<table style="width:100%;">
			<tr>
				<td style='color:#800000;padding-bottom:5px;font-weight:bold;' class='nowrap'><?php print $lang['ws_221'] ?></td>
				<td style='padding-bottom:5px;'>
					<input class='x-form-text x-form-field' style='width:320px;' autocomplete='new-password' type='text' name='fhir_client_id' value='<?php echo htmlspecialchars($element_data['fhir_client_id'], ENT_QUOTES) ?>' />
				</td>
			</tr>
			<tr>
				<td style='color:#800000;font-weight:bold;' class='nowrap'><?php print $lang['ws_222'] ?> &nbsp;</td>
				<td>
					<input class='x-form-text x-form-field' style='width:220px;' autocomplete='new-password' type='password' name='fhir_client_secret' value='<?php echo htmlspecialchars($element_data['fhir_client_secret'], ENT_QUOTES) ?>' />
					<a href="javascript:;" class="cclink" style="text-decoration:underline;font-size:7pt;margin-left:5px;" onclick="$(this).remove();showTwilioAuthToken('fhir_client_secret');"><?php print $lang['ws_223'] ?></a>
				</td>
			</tr>
		</table>
		<div class="cc_info" style="margin-top:15px;">
			<?php echo $lang['ws_232'] ?>
		</div>
	</td>
</tr>

<tr>
	<td class="cc_label" colspan="2" style="padding:20px 10px;">
		<?php echo $lang['ws_224'] ?>
		<div class="cc_info">
			<?php echo $lang['ws_225'] ?>
		</div>
		
		<table style="max-width: 92%;margin-left: 35px;">
			<tr>
				<td style='color:#800000;padding-bottom:10px;padding-top:5px;' class='nowrap'><?php print $lang['ws_228'] ?></td>
				<td style='padding-bottom:10px;padding-top:5px;'>
					<input class='x-form-text x-form-field ' style='width:450px;' type='text' id='fhir_endpoint_base_url' name='fhir_endpoint_base_url' value='<?php echo htmlspecialchars($element_data['fhir_endpoint_base_url'], ENT_QUOTES) ?>' onblur="validateUrl(this);">
					<button class="jqbuttonmed" onclick="setupTestUrl( $('#fhir_endpoint_base_url') );return false;"><?php echo $lang['edit_project_138'] ?></button>
				</td>
			</tr>
			<tr>
				<td colspan='2'>
					<div class="cc_info">
						<?php echo $lang['ws_229'] ?> &nbsp;
						<button class="jqbuttonmed" style="color:#0101bb;font-size: 11px;top: 3px;" onclick="autoFindFhirUrls();return false;"><?php echo $lang['ws_231'] ?></button>
					</div>
				</td>
			</tr>
			<tr>
				<td style='color:#800000;padding-bottom:5px;padding-top:10px;' class='nowrap'><?php print $lang['ws_226'] ?></td>
				<td style='padding-bottom:5px;padding-top:10px;'>
					<input class='x-form-text x-form-field ' style='width:450px;' type='text' id='fhir_endpoint_token_url' name='fhir_endpoint_token_url' value='<?php echo htmlspecialchars($element_data['fhir_endpoint_token_url'], ENT_QUOTES) ?>' onblur="validateUrl(this);">
					<button class="jqbuttonmed" onclick="setupTestUrl( $('#fhir_endpoint_token_url') );return false;"><?php echo $lang['edit_project_138'] ?></button>
				</td>
			</tr>
			<tr>
				<td style='color:#800000;padding-bottom:5px;' class='nowrap'><?php print $lang['ws_227'] ?></td>
				<td style='padding-bottom:5px;'>
					<input class='x-form-text x-form-field ' style='width:450px;' type='text' id='fhir_endpoint_authorize_url' name='fhir_endpoint_authorize_url' value='<?php echo htmlspecialchars($element_data['fhir_endpoint_authorize_url'], ENT_QUOTES) ?>' onblur="validateUrl(this);">
					<button class="jqbuttonmed" onclick="setupTestUrl( $('#fhir_endpoint_authorize_url') );return false;"><?php echo $lang['edit_project_138'] ?></button>
				</td>
			</tr>
		</table>
</tr>

<tr>
	<td class="cc_label">
		<?php echo $lang['ws_217'] ?>
		<div class="cc_info">
			<?php echo $lang['ws_218'] ?>
		</div>
	</td>
	<td class="cc_data">
		<input class='x-form-text x-form-field' style='width:350px;' type='text' name='fhir_ehr_mrn_identifier' value='<?php echo htmlspecialchars($element_data['fhir_ehr_mrn_identifier'], ENT_QUOTES) ?>' /><br/>
		<div class="cc_info">
			e.g., urn:oid:1.2.840.114350.1.13.478.3.7.5.737384.14<br>
			e.g., urn:oid:1.1.1.1.1.1
		</div>
	</td>
</tr>

<?php if (isDev()) { ?>
<tr>
	<td class="cc_label" style="border-top:1px solid #ccc;color:#C00000;" colspan="2">
		<?php echo $lang['ws_244'] ?>
	</td>
</tr>
<tr>
	<td class="cc_label">
		<?php echo $lang['ws_241'] ?>
		<div class="cc_info">
			<?php echo $lang['ws_242'] ?>
		</div>
	</td>
	<td class="cc_data">
		<select class="x-form-text x-form-field" style="" name="fhir_data_mart_create_project">
			<option value='0' <?php echo ($element_data['fhir_data_mart_create_project'] == 0) ? "selected" : "" ?>><?php echo $lang['global_23'] ?></option>
			<option value='1' <?php echo ($element_data['fhir_data_mart_create_project'] == 1) ? "selected" : "" ?>><?php echo $lang['system_config_27'] ?></option>
		</select>
		<div class="cc_info" style="color:#C00000;">
			<?php echo $lang['ws_243'] ?>
		</div>
	</td>
</tr>
<?php } ?>

<tr>
	<td class="cc_label" style="border-top:1px solid #ccc;color:#C00000;" colspan="2">
		<?php echo $lang['ws_233'] ?>
	</td>
</tr>

<tr>
	<td class="cc_label">
		<?php echo $lang['ws_74'] ?>
		<div class="cc_info">
			<?php echo $lang['ws_79'] . " " . $lang['ws_230'] ?>
		</div>
	</td>
	<td class="cc_data">
		<input class='x-form-text x-form-field ' style='width:300px;' type='text' id='fhir_url_user_access' name='fhir_url_user_access' value='<?php echo htmlspecialchars($element_data['fhir_url_user_access'], ENT_QUOTES) ?>' onblur="validateUrl(this);">
		<button class="jqbuttonmed" onclick="setupTestUrl( $('#fhir_url_user_access') );return false;"><?php echo $lang['edit_project_138'] ?></button><br>
		<div class="cc_info">
			<?php echo $lang['ws_94'] ?>
		</div>
		<div class="cc_info" style="color:#800000;">
			<?php echo $lang['ws_97'] ?>
		</div>
	</td>
</tr>

<tr>
	<td class="cc_label">
		<?php echo $lang['ws_69'] ?>
		<div class="cc_info">
			<?php echo $lang['ws_70'] ?>
		</div>
	</td>
	<td class="cc_data">
		<textarea style='height:60px;' class='x-form-field notesbox' name='fhir_custom_text' id='fhir_custom_text'><?php echo $element_data['fhir_custom_text'] ?></textarea>
		<div id='fhir_custom_text-expand' style='text-align:right;'>
			<a href='javascript:;' style='font-weight:normal;text-decoration:none;color:#999;font-family:tahoma;font-size:10px;'
				onclick="growTextarea('fhir_custom_text')"><?php echo $lang['form_renderer_19'] ?></a>&nbsp;
		</div>
		<div class="cc_info">
			<?php echo $lang['system_config_195'] ?>
		</div>
		<div class="cc_info">
			<?php echo $lang['ws_71'] . RCView::br() . RCView::span(array('style'=>'color:#C00000;'), "\"{$lang['ws_50']}\"") ?>
		</div>
	</td>
</tr>

<tr>
	<td class="cc_label">
		<?php echo $lang['ws_75'] ?>
	</td>
	<td class="cc_data">
		<select class="x-form-text x-form-field" style="" name="fhir_display_info_project_setup">
			<option value='0' <?php echo ($element_data['fhir_display_info_project_setup'] == 0) ? "selected" : "" ?>><?php echo $lang['ws_77'] ?></option>
			<option value='1' <?php echo ($element_data['fhir_display_info_project_setup'] == 1) ? "selected" : "" ?>><?php echo $lang['ws_76'] ?></option>
		</select>
		<div class="cc_info">
			<?php echo $lang['ws_78'] ?>
		</div>
	</td>
</tr>

<tr>
	<td class="cc_label">
		<?php echo $lang['ws_80'] ?>
		<div class="cc_info" style="color:#C00000;">
			<?php echo $lang['ws_99'] ?>
		</div>
	</td>
	<td class="cc_data">
		<select class="x-form-text x-form-field" style="" name="fhir_user_rights_super_users_only">
			<option value='0' <?php echo ($element_data['fhir_user_rights_super_users_only'] == 0) ? "selected" : "" ?>><?php echo $lang['ws_81'] ?></option>
			<option value='1' <?php echo ($element_data['fhir_user_rights_super_users_only'] == 1) ? "selected" : "" ?>><?php echo $lang['ws_82'] ?></option>
		</select>
		<div class="cc_info">
			<?php echo $lang['ws_83'] ?>
		</div>
	</td>
</tr>


<tr>
	<td class="cc_label">
		<?php echo $lang['ws_84'] ?>
	</td>
	<td class="cc_data">
		<span class="cc_info" style="font-weight:bold;color:#000;">
			<?php echo $lang['ws_91'] ?>
		</span>
		<input class='x-form-text x-form-field' type='text' style='width:35px;' maxlength='3' onblur="redcap_validate(this,'1','999','hard','int');"  name='fhir_data_fetch_interval' value='<?php echo htmlspecialchars($element_data['fhir_data_fetch_interval'], ENT_QUOTES) ?>' />
		<span class="cc_info" style="font-weight:bold;color:#000;">
			<?php echo $lang['control_center_406'] ?>
		</span>
		<span class="cc_info" style="margin-left:20px;">
			<?php echo $lang['ws_88'] ?>
		</span>
		<div class="cc_info">
			<?php echo $lang['ws_90'] ?>
		</div>
	</td>
</tr>

<tr>
	<td class="cc_label">
		<?php echo $lang['ws_85'] ?>
		<div class="cc_info">
			<?php echo $lang['ws_87'] ?>
		</div>
	</td>
	<td class="cc_data">
		<input class='x-form-text x-form-field' type='text' style='width:35px;' maxlength='3' onblur="redcap_validate(this,'1','100','hard','int');" name='fhir_stop_fetch_inactivity_days' value='<?php echo htmlspecialchars($element_data['fhir_stop_fetch_inactivity_days'], ENT_QUOTES) ?>' />
		<span class="cc_info" style="font-weight:bold;color:#000;">
			<?php echo $lang['scheduling_25'] ?>
		</span>
		<span class="cc_info" style="margin-left:20px;">
			<?php echo $lang['ws_89'] ?>
		</span>
		<div class="cc_info">
			<?php echo $lang['ws_86'] ?>
		</div>
	</td>
</tr>



</table><br/>
<div style="text-align: center;"><input type='submit' name='' value='Save Changes' /></div><br/>
</form>

<?php callJSfile('clipboard.js'); ?>
<script type="text/javascript">
// Function to test the URL via web request and give popup message if failed/succeeded
function validateUrl(ob) {
	ob = $(ob);
	ob.val( trim(ob.val()) );
	var url = ob.val();
	if (url.length == 0) return;
	// Get or set the object's id
	if (ob.attr('id') == null) {
		var input_id = "input-"+Math.floor(Math.random()*10000000000000000);
		ob.attr('id', input_id);
	} else {
		var input_id = ob.attr('id');
	}
	// Disallow localhost
	var localhost_array = new Array('localhost', 'http://localhost', 'https://localhost', 'localhost/', 'http://localhost/', 'https://localhost/');
	if (in_array(url, localhost_array)) {
		simpleDialog('<?php echo js_escape($lang['edit_project_126']) ?>','<?php echo js_escape($lang['global_01']) ?>',null,null,"$('#"+input_id+"').focus();");
		return;
	}
	// Validate URL
	if (!isUrl(url)) {
		if (url.substr(0,4).toLowerCase() != 'http' && isUrl('http://'+url)) {
			// Prepend 'http' to beginning
			ob.val('http://'+url);
			// Now test it again
			validateUrl(ob);
		} else {
			// Error msg
			simpleDialog('<?php echo js_escape($lang['edit_project_126']) ?>','<?php echo js_escape($lang['global_01']) ?>',null,null,"$('#"+input_id+"').focus();");
		}
	}
}
// Perform the setup for testUrl()
function setupTestUrl(ob) {
	if (ob.val() == '') {
		ob.focus();
		return false;
	}
	// Get or set the object's id
	if (ob.attr('id') == null) {
		var input_id = "input-"+Math.floor(Math.random()*10000000000000000);
		ob.attr('id', input_id);
	} else {
		var input_id = ob.attr('id');
	}
	// Test it
	testUrl(ob.val(),'post',"$('#"+input_id+"').focus();");
}
// Auto-find the FHIR authorize and token URLs using base URL
var foundFhirUrls = false;
var metaurl, tokenUrl, authorizeUrl;
function autoFindFhirUrls() {
	foundFhirUrls = false;
	$('#fhir_endpoint_base_url').val().trim();
	var url = $('#fhir_endpoint_base_url').val().replace(/\/$/, "");
	if (url == '') {
		simpleDialog('Please enter a value for the base URL endpoint first', 'ERROR');
		return;
	}
	var k = 0;
	// Start "working..." progress bar
	showProgress(1,0);
	// Loop through URL and sub-URLs till we find the right metadata path
	while (k < 25 && foundFhirUrls === false) {		
		if (url == '' || url == 'https:/' || url == 'http:/' || url == 'https:' || url == 'http:') {
			break;
		}
		// Do ajax request to test the URL
		var thisAjax = $.ajax({
			url: '<?php echo PAGE_FULL ?>',
			type: 'POST',
			data: { url: url+"/metadata", redcap_csrf_token: redcap_csrf_token },
			async: false,
			success:
				function(data){
					if (data != '0') foundFhirUrls = data;
					metaurl = url+"/metadata";
				}
		});
		// Prep for the next loop
		url = dirname(url);
		k++;
	}
	showProgress(0,0);
	if (foundFhirUrls !== false) {
		var urls = foundFhirUrls.split("\n");
		authorizeUrl = urls[0];
		tokenUrl = urls[1];
		simpleDialog("The FHIR URLs below for your Authorize endpoint and Token endpoint were found from the FHIR Conformance Statement (<i>"+metaurl+"</i>). "
			+ "You may copy these URLs into their corresponding text boxes on this page."
			+ "<div style='font-size:13px;padding:20px 0 5px;color:green;'>Token endpoint: &nbsp;<b>"+tokenUrl+"</b></div>"
			+ "<div style='font-size:13px;padding:5px 0;color:green;'>Authorize endpoint: &nbsp;<b>"+authorizeUrl+"</b></div>",
			"<img src='"+app_path_images+"tick.png' style='vertical-align:middle;'> <span style='color:green;vertical-align:middle;'>Success!</span>",null,600,null,'Close',function(){
				$('#fhir_endpoint_authorize_url').val(authorizeUrl).effect('highlight',{},3000);
				$('#fhir_endpoint_token_url').val(tokenUrl).effect('highlight',{},3000);
			},'Copy');
	} else {
		simpleDialog("The FHIR Conformance Statement that contains the values of the URLs for your FHIR Authorize endpoint and FHIR Token endpoint could not found under your FHIR base URL nor under any higher-level directories. "
			+ "You should consult your EHR's technical technical team to determine these two FHIR endpoints. The DDP on FHIR function cannot work successfully without these URLs being set.", "<img src='"+app_path_images+"cross.png' style='vertical-align:middle;'> <span style='color:#C00000;vertical-align:middle;'>Failed to find FHIR Conformance Statement</span>");
	}
}
// Copy the public survey URL to the user's clipboard
function copyUrlToClipboard(ob) {
	// Create progress element that says "Copied!" when clicked
	var rndm = Math.random()+"";
	var copyid = 'clip'+rndm.replace('.','');
	var clipSaveHtml = '<span class="clipboardSaveProgress" id="'+copyid+'">Copied!</span>';
	$(ob).after(clipSaveHtml);
	$('#'+copyid).toggle('fade','fast');
	setTimeout(function(){
		$('#'+copyid).toggle('fade','fast',function(){
			$('#'+copyid).remove();
		});
	},2000);
}
// Copy-to-clipboard action
var clipboard = new Clipboard('.btn-clipboard');
$(function(){
	// Copy-to-clipboard action
	$('.btn-clipboard').click(function(){
		copyUrlToClipboard(this);
	});
});
</script>


<?php include 'footer.php'; ?>