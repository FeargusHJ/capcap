<?php
/*****************************************************************************************
**  REDCap is only available through a license agreement with Vanderbilt University
******************************************************************************************/

include_once dirname(dirname(__FILE__)) . '/Config/init_project.php';

?>
<p>
	<?php echo $lang['calc_disclaimer_01'] ?>
</p>
<p>
	<?php echo $lang['calc_disclaimer_02'] ?>
</p>
<p style="font-weight:bold;">
	<?php echo $lang['calc_disclaimer_03'] ?>
</p>