<?php

class FhirServices
{
    private $endpoint;
    private $clientId;
    private $clientSecret;
	private $authorizeUrl;
	private $tokenUrl;

    public function __construct($endpoint, $clientId=null, $clientSecret=null)
    {
        // Endpoint and client id are passed in via service configuration
        $this->endpoint = $endpoint;
        $this->clientId = $clientId;
        $this->clientSecret = $clientSecret;
    }

    public function setAuthorizeTokenUrls()
    {
		global $fhir_endpoint_authorize_url, $fhir_endpoint_token_url;
		// If authorize and token endpoints are stored in config, then use those, otherwise fetch them from the conformance statement
		if ($fhir_endpoint_authorize_url != '') {
			$this->authorizeUrl = $fhir_endpoint_authorize_url;
		}
		if ($fhir_endpoint_token_url != '') {
			$this->tokenUrl = $fhir_endpoint_token_url;
		}
		// If we have both URLs, then nothing else to do
		if ($this->authorizeUrl != '' && $this->tokenUrl != '') return;
		
		// Set metadata URL of conformance statement
		$metadataEndPoint = $this->endpoint . "metadata";		
		// Conformance statement - obtain authorize endpoint URL and token endpoint URL
		$response = http_get($metadataEndPoint, 30, "", array('Accept: application/json'));
		if (!$response) throw new Exception("Could not make a successful call to the Conformance Statement at " . $this->endpoint . "metadata");
		$metadata = json_decode($response, true);
		if (!is_array($metadata)) throw new Exception("Could not parse the Conformance Statement from " . $this->endpoint . "metadata");		
		// Get authorize endpoint URL and token endpoint URL
		foreach ($metadata['rest'][0]['security']['extension'][0]['extension'] as $attr) {
			if ($attr['url'] == 'authorize') {
				$this->authorizeUrl = $attr['valueUri'];
			} elseif ($attr['url'] == 'token') {
				$this->tokenUrl = $attr['valueUri'];
			}
		}
	}
	
    public function getAuthorizeUrl($redirectUrl, $scope='patient/*.read', $state='123456789', $launch=null)
    {
		$this->setAuthorizeTokenUrls();
        $params = array(
            'response_type' => 'code',
            'client_id' => $this->clientId,
			'scope' => $scope,
            'redirect_uri' => $redirectUrl,
			'aud' => $this->endpoint,
			'state' => $state
        );
		if (!empty($launch)) $params['launch'] = $launch;
		return $this->authorizeUrl . '?' . http_build_query($params);
    }

    public function getAuthToken($code, $redirectUrl)
    {
		$this->setAuthorizeTokenUrls();		
		$headers = array();
        $params = array(
            'code' => $code,
            'grant_type' => 'authorization_code',
            'redirect_uri' => $redirectUrl
        );
		if (empty($this->clientSecret)) {
			$params['client_id'] = $this->clientId;
		} else {
			$headers = array("Authorization: Basic " . base64_encode($this->clientId.":".$this->clientSecret));
		}
		// Make POST request to token endpoint URL
		$response = http_post($this->tokenUrl, $params, 30, 'application/x-www-form-urlencoded', "", $headers);
		$token_info = json_decode($response);
		// If failed, return false, else return access token
		return is_object($token_info) ? $token_info : false;
    }

    public function getAuthTokenViaRefreshToken($refresh_token)
    {
		if (empty($refresh_token)) return false;
		$this->setAuthorizeTokenUrls();		
		$headers = array();
        $params = array(
            'refresh_token' => $refresh_token,
            'grant_type' => 'refresh_token'
        );
		// Must have a secret for a confidential client
		if (empty($this->clientSecret)) return false;
		$headers = array("Authorization: Basic " . base64_encode($this->clientId.":".$this->clientSecret));
		// Make POST request to token endpoint URL
		$response = http_post($this->tokenUrl, $params, 30, 'application/x-www-form-urlencoded', "", $headers);
		$token_info = json_decode($response);
		// If failed, return false, else return access token
		return is_object($token_info) ? $token_info : false;
    }
	
	// Return the institution-specific version of the MRN (e.g., $system_string='urn:oid:1.2.5.8.2.7' for Vanderbilt MRN)
    public function getPatientMrn($patient_info, $system_string='')
    {
		if (!empty($system_string) && is_object($patient_info) && isset($patient_info->identifier)) {
			foreach ($patient_info->identifier as $identifier) {
				if (isset($identifier->system) && $identifier->system == $system_string && isset($identifier->value)) {
					return $identifier->value;
				}
			}
		}
		return false;
    }

    public function getPatientDemographics($access_token=null, $patient=null)
    {
        if (empty($access_token) || empty($patient)) {
            return false;
        }
		$url = $this->endpoint . 'Patient/' . $patient;
		$headers = array('Authorization: Bearer ' . $access_token, 'Accept: application/json');
		$response = http_get($url, null, "", $headers);
		$patient_info = json_decode($response);		
		if (!empty($patient_info) && is_object($patient_info)) {
			return $patient_info;
		}
		return false;
    }

    public function getPatientData($url=null, $access_token=null)
    {
        if (empty($access_token)) {
            return false;
        }
		$headers = array('Authorization: Bearer ' . $access_token, 'Accept: application/json');
		$response = http_get($url, null, "", $headers);
		$patient_info = json_decode($response);				
		if (!empty($patient_info) && is_object($patient_info) && !isset($patient_info->error)) {
			return $patient_info;
		}
		return false;
    }
}
