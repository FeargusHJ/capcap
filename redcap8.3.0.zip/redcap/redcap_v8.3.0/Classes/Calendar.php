<?php

class Calendar
{
	// Return boolean if $record has at least one calendar event associated with it
	public static function recordHasCalendarEvents($record)
	{
		global $Proj;
		$sql = "select 1 from redcap_events_calendar where project_id = " . PROJECT_ID . " 
				and (event_id is null or event_id in (".prep_implode(array_keys($Proj->eventInfo)).")) 
				and record = '".db_escape($record)."' limit 1";
		$q = db_query($sql);
		return (db_num_rows($q) > 0);		
	}
	
	// Return HTML table agenda for calendar events in next $daysFromNow days (optional: limit to a specific $record)
	public static function renderUpcomingAgenda($daysFromNow=7, $record=null, $returnCountOnly=false, $showTableTitle=true)
	{
		global $lang, $user_rights, $Proj;
		if (!is_numeric($daysFromNow)) return false;
		// Exclude records not in your DDE group (if using DDE)
		$dde_sql = "";
		if ($double_data_entry && isset($user_rights['double_data']) && $user_rights['double_data'] != 0) {
			$dde_sql = "and record like '%--{$user_rights['double_data']}'";
		}
		// If returning single record
		$record_sql = "";
		if ($record !== null) {
			$record_sql = "and record = '".db_escape($record)."'";
		}
		// Get calendar events
		$sql = "select * from redcap_events_calendar where project_id = " . PROJECT_ID . " 
				and (event_id is null or event_id in (".prep_implode(array_keys($Proj->eventInfo)).")) and event_date >= '" . date("Y-m-d") . "' 
				and event_date <= '" . date("Y-m-d", mktime(0, 0, 0, date("m"), date("d")+$daysFromNow, date("Y"))) . "'
				" . (($user_rights['group_id'] == "") ? "" : "and group_id = " . $user_rights['group_id']) . " 
				$dde_sql $record_sql order by event_date, event_time";
		$q = db_query($sql);

		$cal_list = array();
		$num_rows = db_num_rows($q);
		
		if ($returnCountOnly) return $num_rows;

		if ($num_rows > 0) {

			while ($row = db_fetch_assoc($q))
			{
				$caldesc = "";
				// Set image to load calendar pop-up
				$popup = "<a href=\"javascript:;\" onclick=\"popupCal({$row['cal_id']},800);\">"
						 . "<img src=\"".APP_PATH_IMAGES."magnifier.png\" style=\"vertical-align:middle;\" title=\"".js_escape2($lang['scheduling_80'])."\" alt=\"".js_escape2($lang['scheduling_80'])."\"></a> ";
				// Trim notes text
				$row['notes'] = trim($row['notes']);
				// If this calendar event is tied to a project record, display record and Event
				if ($row['record'] != "") {
					$caldesc .= removeDDEending($row['record']);
				}
				if ($row['event_id'] != "") {
					$caldesc .= " (" . $Proj->eventInfo[$row['event_id']]['name_ext'] . ") ";
				}
				if ($row['group_id'] != "") {
					$caldesc .= " [" . $Proj->getGroups($row['group_id']) . "] ";
				}
				if ($row['notes'] != "") {
					if ($row['record'] != "" || $row['event_id'] != "") {
						$caldesc .= " - ";
					}
					$caldesc .= $row['notes'];
				}
				// Add to table
				$cal_list[] = array($popup, DateTimeRC::format_ts_from_ymd($row['event_time']), DateTimeRC::format_ts_from_ymd($row['event_date']), "<span class=\"notranslate\">".RCView::escape($caldesc)."</span>");
			}

		} else {

			$cal_list[] = array('', '', '', $lang['index_52']);

		}
		
		$height = (count($cal_list) < 9) ? "auto" : 220;
		$width = 500;
		$title = $instructions = $divClasses = "";
		if ($showTableTitle) {
			$divClasses = "col-xs-12 col-sm-6";
			$title = "<div style=\"padding:0;\"><img src=\"".APP_PATH_IMAGES."date.png\">
					  <span style=\"color:#800000;\">{$lang['index_53']} &nbsp;<span style=\"font-weight:normal;\">{$lang['index_54']}</span></span></div>";
		} else {
			$instructions = RCView::div(array('style'=>'margin-bottom:10px;'), $lang['calendar_16'] . " ". RCView::b("$daysFromNow " . $lang['scheduling_25']) . $lang['period']);
		}
		$col_widths_headers = array(
								array(18, '', 'center'),
								array(50,  $lang['global_13']),
								array(70,  $lang['global_18']),
								array(316, $lang['global_20'])
							  );
		
		// Build HTML
		$html = "<div class='$divClasses'>$instructions";
		$html .= renderGrid("cal_table", $title, $width, $height, $col_widths_headers, $cal_list, true, true, false);
		$html .= "<div style='margin-top:10px;'></div></div>";
		
		return $html;
	}
}
