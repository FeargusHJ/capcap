<?php

/*****************************************************************************************
**  REDCap is only available through a license agreement with Vanderbilt University
******************************************************************************************/

/**
 * Exceptions produced by the Data Quality lexer/parser/module.
 */
class LogicException extends Exception {}