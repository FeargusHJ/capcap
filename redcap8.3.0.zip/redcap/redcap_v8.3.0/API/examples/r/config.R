
api_super_token <- 'ABCD1234ABCD1234ABCD1234ABCD1234ABCD1234ABCD1234ABCD1234ABCD1234'
api_token       <- '123C09E18E718B5BDA693467A304EA32'
api_url         <- 'http://example.com/redcap/api/'
