<?php
/*****************************************************************************************
**  REDCap is only available through a license agreement with Vanderbilt University
******************************************************************************************/

// Call file containing basic functions for this config file	.
require_once dirname(__FILE__) . '/init_functions.php';
// Initialize for project-level pages
System::initProjectPage();